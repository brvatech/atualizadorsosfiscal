﻿Public Class Liberacao_Senhavb
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        SenhaCorreta = False
        Me.Close()
    End Sub

    Private Sub Liberacao_Senhavb_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBoxSenha.Focus()
        InsereEnter(Me)
    End Sub

    Private Sub Button_OK_Click(sender As Object, e As EventArgs) Handles Button_OK.Click

        If TextBoxSenha.Text = calculo_senha Then

            SenhaCorreta = True
            Me.Close()
        Else
            MsgBox("Senha Inválida!", vbExclamation, "Controle de Usuário >>")
            TextBoxSenha.Focus()
            Exit Sub
        End If

    End Sub
End Class