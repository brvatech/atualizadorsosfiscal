1 - COPIAR NSSM NA PASTA:
"C:\Program Files (x86)\SOS FISCAL\nssm-2.24\win64\nssm.exe"
2 - Executar como ADM Instalar Servico Monitor.bat
