﻿Imports System.Management
Imports System.Net
Imports System.Net.Http
Imports System.Text
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient
Imports Mysqlx.XDevAPI.Relational
Imports Org.BouncyCastle.Pqc.Crypto.Frodo
Imports Renci.SshNet

Public Class Requisicao_Lote_Produtos
    Public Declare Auto Function GetPrivateProfileString Lib "Kernel32" (ByVal lpAppName As String, ByVal lpKeyName As String, ByVal lpDefault As String, ByVal lpReturnedString As StringBuilder, ByVal nSize As Integer, ByVal lpFileName As String) As Integer
    Public Declare Auto Function WritePrivateProfileString Lib "Kernel32" (ByVal lpAppName As String, ByVal lpKeyName As String, ByVal lpString As String, ByVal lpFileName As String) As Integer

    Public Function LeArquivoINI(ByVal file_name As String, ByVal section_name As String, ByVal key_name As String, ByVal default_value As String) As String

        Const MAX_LENGTH As Integer = 500
        Dim string_builder As New StringBuilder(MAX_LENGTH)
        GetPrivateProfileString(section_name, key_name, default_value, string_builder, MAX_LENGTH, file_name)
        Return string_builder.ToString()

    End Function

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

        If ComboBox_Servico.Text = "DESATIVADO" Then
            ComboBox_Servico.BackColor = Color.Red
        ElseIf ComboBox_Servico.Text = "ATIVO" Then
            ComboBox_Servico.BackColor = Color.Lime
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Dim form As New Liberacao_Senhavb
        form.ShowDialog()

        If SenhaCorreta = True Then
            Me.Close()
        End If
        SenhaCorreta = False

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Visible = False
    End Sub

    Private Sub ConfigurarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConfigurarToolStripMenuItem.Click
        Me.Visible = True
        ler_config_ini()
        LabelAtualizados.Text = "Produtos Atualizados no Banco de Dados: " & Config_Produtos_Atualizados
        Label_Consultados.Text = "Produtos Consultados: " & Config_Produtos_Consultados
        Label_Ultima_consulta.Text = "Última consulta Realizada ao Portal: " & Config_Data_Ultima_Consulta & " - " & strhoraatualizacao
        CalculoSenhaDiaria()
    End Sub

    Private Sub FecharToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FecharToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub Button_Executar_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Requisicao_Lote_Produtos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ler_config_ini()
        CalculoSenhaDiaria()
        IniciarFormulario()
        InsereEnter(Me)
        CarregarConfigDesktop()
        LabelBuild.Text = "Brvatech Tecnologia  - Build " & buildsosfiscal
        Me.Text = "Brvatech Tecnologia  - Build " & buildsosfiscal
        Me.Tag = "Brvatech Tecnologia  - Build " & buildsosfiscal
    End Sub

    Sub CarregarConfigDesktop()

        TextBox_IpDesktop.Text = strServidor
        TextBox_portaDesktop.Text = strPorta
        TextBox_UsuarioDesktop.Text = strUsuario
        TextBox_senhaDesktop.Text = strSenha
        TextBox_databaseDesktop.Text = strBanco

    End Sub

    Sub IniciarFormulario()

        Carregar_dados_Cliente()

        TextBox_CNPJ.Text = cnpj_cadastro
        TextBox_Razao_Social.Text = razao_cadastro
        TextBox_CNAE.Text = cnae_cadastro
        ComboBox_ID.Items.Add(strIdCliente)
        ComboBox_ID.Text = strIdCliente

        ComboBox_Ambiente.Items.Add("1 - HOMOLOGAÇÃO")
        ComboBox_Ambiente.Items.Add("2 - PRODUÇÃO")
        ComboBox_tipoCliente.Items.Add("WEB")
        ComboBox_tipoCliente.Items.Add("DESKTOP")

        TextBox_Usuario_Api.Text = strusuario_Api
        TextBox_Senha_Api.Text = strsenha_Api
        ComboBox_Servico.Text = strstatusservico

        If strstatusservico = "ATIVO" Then
            ComboBox_Servico.BackColor = Color.Lime
        ElseIf strstatusservico = "DESATIVADO" Then
            ComboBox_Servico.BackColor = Color.Red
        End If

        If tp_enquadramento = 1 Then
            TextBox_Regime_Tributario.Text = tp_enquadramento & " - Simples Nacional"
            TextBox_Codigo_Faixa.Text = codigo_faixa
        ElseIf tp_enquadramento = 2 Then
            TextBox_Regime_Tributario.Text = tp_enquadramento & " - Lucro Real"
            TextBox_Codigo_Faixa.Text = codigo_faixa
        ElseIf tp_enquadramento = 0 Then
            TextBox_Regime_Tributario.Text = tp_enquadramento & " - Lucro Presumido"
            TextBox_Codigo_Faixa.Text = codigo_faixa
        End If

        If strtipoConexao = "DESKTOP" Then
            ComboBox_tipoCliente.Text = strtipoConexao
        ElseIf strtipoConexao = "WEB" Then
            ComboBox_tipoCliente.Text = strtipoConexao
        End If

        ComboBox_tipoCliente.Text = ComboBox_tipoCliente.Text.ToUpper()
        TextBox_Contribuinte.Text = "NÃO"
        TextBox_UF.Text = estado

        If strambiente_Api = 2 Then
            ComboBox_Ambiente.Text = "2 - PRODUÇÃO"
        ElseIf strambiente_Api = 1 Then
            ComboBox_Ambiente.Text = "1 - HOMOLOGAÇÃO"
        ElseIf strambiente_Api <> 1 Or 2 Then
            MsgBox("CONFIGURAÇÃO DE AMBIENTE DA API INVÁLIDA!", vbInformation)
            ComboBox_Ambiente.Focus()
        End If

        LabelAtualizados.Text = "Produtos Atualizados no Banco de Dados: " & Config_Produtos_Atualizados
        Label_Consultados.Text = "Produtos Consultados: " & Config_Produtos_Consultados
        Label_Ultima_consulta.Text = "Última consulta Realizada ao Portal: " & Config_Data_Ultima_Consulta & " - " & strhoraatualizacao

        TextBox_MovEstoque.Text = strdiasmovimentoestoque
        TextBoxConfig_MP.Text = strdiasmovimentoestoque
        TextBox_AtuSOS.Text = strdiasatualizacaotributo
        TextBoxConfig_ASF.Text = strdiasatualizacaotributo
        ComboBox_Agendamento.Text = strhorarioagendamento

        For hora As Integer = 0 To 24
            Dim horaFormatada As String = hora.ToString("D2") & ":00"
            ComboBox_Agendamento.Items.Add(horaFormatada)
        Next
        Agendamento.IniciarAgendamento()
    End Sub

    Private Sub TextBox_MovEstoque_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox_AtuSOS_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            ' Se não for um número e não for uma tecla de controle, cancela a entrada
            e.Handled = True
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles ComboBox_Servico.SelectedIndexChanged
        If ComboBox_Servico.Text = "ATIVO" Then
            ComboBox_Servico.BackColor = Color.Lime
        ElseIf ComboBox_Servico.Text = "DESATIVADO" Then
            ComboBox_Servico.BackColor = Color.Red
        End If
    End Sub

    Private Async Sub Button_Executar_Click_1(sender As Object, e As EventArgs) Handles Button_Executar.Click

        Dim frm As New Liberacao_Senhavb

        frm.ShowDialog()

        If SenhaCorreta = True Then

            Visible = False

            If CheckBox_produtos.Checked = True Then
                EnviarTodosProdutos = True
            ElseIf CheckBox_produtos.Checked = False Then
                EnviarTodosProdutos = False
            End If

            Await Contar_Produtos_requisicao()

            If NumeroProdutoConsultados < 500 Then
                Await Requisicao_POST_Abaixo_500()
                LabelAtualizados.Text = "Produtos Atualizados no Banco de Dados: " & NumeroProdutoRetornados
            Else
                Await Requisicao_POST_Lote_500()
                LabelAtualizados.Text = "Produtos Atualizados no Banco de Dados: " & SomaProdutosRetornados
                NumeroProdutoRetornados = SomaProdutosRetornados
            End If

            Visible = True
            SenhaCorreta = False


            Dim data = Date.Now
            Dim DataFormatada = data.ToString("dd/MM/yyyy")
            Dim horaFormatada = data.ToString("HH:mm:ss")

            Label_Consultados.Text = "Produtos Consultados: " & NumeroProdutoConsultados
            Label_Ultima_consulta.Text = "Última consulta Realizada ao Portal: " & DataFormatada & " - " & horaFormatada


            Dim nome_arquivo_ini = "C:\Program Files (x86)\SOS Fiscal\config_server.ini"

            WritePrivateProfileString("API_BRVATECH", "DATAULTIMACONSULTA", DataFormatada, nome_arquivo_ini)
            WritePrivateProfileString("API_BRVATECH", "HORARIOULTIMAATUALIZACAO", horaFormatada, nome_arquivo_ini)
            WritePrivateProfileString("API_BRVATECH", "PRODUTOSCONSULTADOS", NumeroProdutoConsultados, nome_arquivo_ini)
            WritePrivateProfileString("API_BRVATECH", "PRODUTOSATUALIZADOS", NumeroProdutoRetornados, nome_arquivo_ini)
            dt_Numero_produtos.Clear()

        End If
    End Sub

    Public Async Function ExecutarRequisicaoDesktopAsync() As Task

        If CheckBox_produtos.Checked = True Then
            EnviarTodosProdutos = True
        ElseIf CheckBox_produtos.Checked = False Then
            EnviarTodosProdutos = False
        End If

        Await Contar_Produtos_requisicao()

        If NumeroProdutoConsultados < 500 Then
            Await Requisicao_POST_Abaixo_500()
            LabelAtualizados.Text = "Produtos Atualizados no Banco de Dados: " & NumeroProdutoRetornados
        Else
            Await Requisicao_POST_Lote_500()
            LabelAtualizados.Text = "Produtos Atualizados no Banco de Dados: " & SomaProdutosRetornados
            NumeroProdutoRetornados = SomaProdutosRetornados
        End If

        Visible = True
        SenhaCorreta = False


        Dim data = Date.Now
        Dim DataFormatada = data.ToString("dd/MM/yyyy")
        Dim horaFormatada = data.ToString("HH:mm:ss")

        Label_Consultados.Text = "Produtos Consultados: " & NumeroProdutoConsultados
        Label_Ultima_consulta.Text = "Última consulta Realizada ao Portal: " & Config_Data_Ultima_Consulta & " - " & strhoraatualizacao


        Dim nome_arquivo_ini = "C:\Program Files (x86)\SOS Fiscal\config_server.ini"

        WritePrivateProfileString("API_BRVATECH", "DATAULTIMACONSULTA", DataFormatada, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "HORARIOULTIMAATUALIZACAO", horaFormatada, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "PRODUTOSCONSULTADOS", NumeroProdutoConsultados, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "PRODUTOSATUALIZADOS", NumeroProdutoRetornados, nome_arquivo_ini)
        dt_Numero_produtos.Clear()


    End Function

    Public Async Function ExecutarRequisicaoWebAsync() As Task


        abrir_mysql()

        Try

            Dim cmd As MySqlCommand
            Dim dt As New DataTable
            Dim sqlConsulta As String

            sqlConsulta = "SELECT id, usuariopg, senhapg, portapg, ipexternoservidor, tenant, horaagendamento FROM websos"
            cmd = New MySqlCommand(sqlConsulta, conexao_Msql)
            Using da = New MySqlDataAdapter(sqlConsulta, conexao_Msql)
                da.Fill(dt)

                For Each dados As DataRow In dt.Rows

                    strServidor = dados("ipexternoservidor").ToString()
                    strBanco = dados("tenant").ToString()
                    strPorta = dados("portapg").ToString()
                    strSenha = dados("senhapg").ToString()

                    Dim senha = "hm1722+#()"
                    If strSenha <> "" Then
                        strSenha = Decriptar(strSenha, senha)
                    End If

                    conexao_postgresWeb = ($“server={strServidor};port={strPorta};userid={strUsuario};password={strSenha};database={strBanco}")

                    Await Contar_Produtos_requisicao()

                    If NumeroProdutoConsultados < 500 Then
                        Await Requisicao_POST_Abaixo_500()
                        LabelAtualizados.Text = "Produtos Atualizados no Banco de Dados: " & NumeroProdutoRetornados
                    Else
                        Await Requisicao_POST_Lote_500()
                        LabelAtualizados.Text = "Produtos Atualizados no Banco de Dados: " & SomaProdutosRetornados
                        NumeroProdutoRetornados = SomaProdutosRetornados
                    End If

                Next

                dt.Clear()

            End Using

        Catch ex As Exception
            MsgBox(vbExclamation + ex.Message)
        End Try
        fechar_mysql()

        Visible = True
        SenhaCorreta = False

    End Function

    Private Sub ProdutosConsultados()

        Dim data As DateTime = DateTime.Now
        Dim DataFormatada As String = data.ToString("dd/MM/yyyy")
        Dim horaFormatada As String = data.ToString("HH:mm:ss")
        LabelAtualizados.Text = "Produtos Atualizados no Banco de Dados: " & NumeroProdutoRetornados
        Label_Consultados.Text = "Produtos Consultados: " & NumeroProdutoConsultados
        Label_Ultima_consulta.Text = "Última consulta Realizada ao Portal: " & Config_Data_Ultima_Consulta & " - " & strhoraatualizacao


        Dim nome_arquivo_ini As String = "C:\Program Files (x86)\SOS Fiscal\config_server.ini"

        WritePrivateProfileString("API_BRVATECH", "DATAULTIMACONSULTA", DataFormatada, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "HORARIOULTIMAATUALIZACAO", horaFormatada, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "PRODUTOSCONSULTADOS", NumeroProdutoConsultados, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "PRODUTOSATUALIZADOS", NumeroProdutoRetornados, nome_arquivo_ini)

    End Sub

    Private Sub Gravar_config_ini()


        Dim nome_arquivo_ini As String = "C:\Program Files (x86)\SOS Fiscal\config_server.ini"

        If ComboBox_Ambiente.Text = "1 - HOMOLOGAÇÃO" Then
            strambiente_Api = 1
        ElseIf ComboBox_Ambiente.Text = "2 - PRODUÇÃO" Then
            strambiente_Api = 2
        End If


        Dim senha As String = "hm1722+#()"

        senha_postgresDesktop = Criptar(TextBox_senhaDesktop.Text, senha)

        If ComboBox_tipoCliente.Text = "DESKTOP" Then
            'CONFIG SERVIDOR DESKTOP--------------------------------------------------------------------------------------
            WritePrivateProfileString("GERAL", "SERVER", TextBox_IpDesktop.Text, nome_arquivo_ini)
            WritePrivateProfileString("GERAL", "PORTA", TextBox_portaDesktop.Text, nome_arquivo_ini)
            WritePrivateProfileString("GERAL", "USERNAME", TextBox_UsuarioDesktop.Text, nome_arquivo_ini)
            WritePrivateProfileString("GERAL", "PASSWORD", senha_postgresDesktop, nome_arquivo_ini)
            WritePrivateProfileString("GERAL", "DATABASE", TextBox_databaseDesktop.Text, nome_arquivo_ini)
        End If

        'CONFIG API---------------------------------------------------------------------------------------------------
        WritePrivateProfileString("API_BRVATECH", "USUARIO_API", TextBox_Usuario_Api.Text, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "SENHA_API", TextBox_Senha_Api.Text, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "AMB_API", strambiente_Api, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "DIASMOVIMENTOESTOQUE", TextBoxConfig_MP.Text, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "DIASATUALIZACAOTRIBUTO", TextBoxConfig_ASF.Text, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "HORARIOAGENDAMENTO", ComboBox_Agendamento.Text, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "STATUS_SERVICO", ComboBox_Servico.Text, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "TIPO_CLIENTE", ComboBox_tipoCliente.Text, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "ID_CLIENTE", ComboBox_ID.Text, nome_arquivo_ini)

        MsgBox("CONFIGURAÇÃO GRAVADA COM SUCESSO! Reinicie o Serviço para que As alterações tenham efeito!", vbInformation)

    End Sub

    Private Sub Gravar_config_Atualizacao_ini()

        Dim data As DateTime = DateTime.Now
        Dim DataFormatada As String = data.ToString("dd/MM/yyyy")
        Dim horaFormatada As String = data.ToString("HH:mm:ss")

        Dim nome_arquivo_ini As String = "C:\Program Files (x86)\SOS Fiscal\config_server.ini"

        WritePrivateProfileString("API_BRVATECH", "DATAULTIMACONSULTA", DataFormatada, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "PRODUTOSCONSULTADOS", NumeroProdutoConsultados, nome_arquivo_ini)
        WritePrivateProfileString("API_BRVATECH", "PRODUTOSATUALIZADOS", NumeroProdutoRetornados, nome_arquivo_ini)

    End Sub

    Private Sub TextBoxConfig_MP_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBoxConfig_MP.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            ' Se não for um número ou uma tecla de controle, cancela o evento
            e.Handled = True
        End If
    End Sub
    Private Sub TextBoxConfig_ASF_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBoxConfig_ASF.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            ' Se não for um número ou uma tecla de controle, cancela o evento
            e.Handled = True
        End If
    End Sub

    Private Sub Button_Salvar_Click(sender As Object, e As EventArgs) Handles Button_Salvar.Click

        Dim form As New Liberacao_Senhavb
        form.ShowDialog()


        If SenhaCorreta = True Then
            Gravar_config_ini()
        End If
        SenhaCorreta = False
        Me.Close()
    End Sub

    Sub ControleConexao()

        Dim tabPageIndexDesktop As Integer = 3
        Dim tabPageIndexWeb As Integer = 2

        If ComboBox_tipoCliente.Text = "DESKTOP" Then
            For Each control As Control In TabControl1.TabPages(tabPageIndexWeb).Controls
                control.Enabled = False
            Next
            For Each control As Control In TabControl1.TabPages(tabPageIndexDesktop).Controls
                control.Enabled = True
            Next
        ElseIf ComboBox_tipoCliente.Text = "WEB" Then
            For Each control As Control In TabControl1.TabPages(tabPageIndexWeb).Controls
                control.Enabled = True
            Next
            For Each control As Control In TabControl1.TabPages(tabPageIndexDesktop).Controls
                control.Enabled = False
            Next
        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)

        Dim form As New Liberacao_Senhavb
        form.ShowDialog()

        If SenhaCorreta = True Then
            Gravar_config_ini()
        End If
        SenhaCorreta = False
        Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles ButtonDesktop.Click

        Dim form As New Liberacao_Senhavb
        form.ShowDialog()


        If SenhaCorreta = True Then
            Gravar_config_ini()
        End If
        SenhaCorreta = False
        Me.Close()
    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click
        Try


            Dim conexao_teste = ($“server={TextBox_IpDesktop.Text};port={TextBox_portaDesktop.Text };userid={TextBox_UsuarioDesktop.Text};password={TextBox_senhaDesktop.Text};database={TextBox_databaseDesktop.Text}")

            conexao_pg = New NpgsqlConnection(conexao_teste)

            If conexao_pg.State = 0 Then

                conexao_pg.Open()
                MsgBox("CONEXÃO EFETUADA COM SUCESSO!", vbInformation, "Teste de Conexão")

            End If

        Catch ex As Exception
            MsgBox("ERRO AO CONECTAR NO BANCO DE DADOS!  -  " + ex.Message, vbCritical, "Teste de Conexão")
        End Try
    End Sub

    Private Sub ComboBox_ID_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_ID.SelectedIndexChanged
        Carregar_dados_Cliente()
        TextBox_Razao_Social.Text = razao_cadastro
        TextBox_CNAE.Text = cnae_cadastro
        ComboBox_ID.Text = strIdCliente
    End Sub

    Private Sub TextBox_senhaDesktop_TextChanged(sender As Object, e As EventArgs) Handles TextBox_senhaDesktop.TextChanged

    End Sub

    Private Async Function Button5_ClickAsync(sender As Object, e As EventArgs) As Task Handles Button5.Click

        Carregar_dados_Cliente()

        ' Configurar o HttpClient
        Dim URL As String = "http://consultatributos.com.br:8080/api/v1/public/GetStatusCliente/" & CNPJ_Formatado
        Dim usuario As String = strusuario_Api
        Dim senha As String = strsenha_Api
        Dim client As HttpClient = New HttpClient()
        client.BaseAddress = New Uri(URL)
        client.DefaultRequestHeaders.Add("login", usuario)
        client.DefaultRequestHeaders.Add("senha", senha)
        Dim conteudoResposta As String = String.Empty

        ' Configurar a autenticação
        Dim byteArray As Byte() = Encoding.UTF8.GetBytes($"{usuario}:{senha}")
        client.DefaultRequestHeaders.Authorization = New System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray))

        ' Enviar a requisição GET
        Dim response As HttpResponseMessage = Await client.GetAsync(URL)

        ' Processar a resposta
        If response.IsSuccessStatusCode Then
            ' Ler o conteúdo da resposta
            conteudoResposta = Await response.Content.ReadAsStringAsync()

            ' Verificar o status do cliente
            Dim json As JObject = JObject.Parse(conteudoResposta)
            Dim sucesso As Boolean = json("sucesso").ToObject(Of Boolean)()

            If sucesso Then
                MsgBox("Cliente Liberado", vbInformation)
            Else
                Dim mensagem As String = json("mensagem").ToObject(Of String)()
                MsgBox($"Cliente Bloqueado: {mensagem}", vbCritical)
            End If
        Else
            Dim codigo_resposta As HttpStatusCode = response.StatusCode
            MsgBox($"Erro na requisição: {codigo_resposta} - {response.ReasonPhrase}")
        End If

    End Function
    Private Sub BtnEnviarDados_Click(sender As Object, e As EventArgs)
        EnviarStatusPainel()
    End Sub
    Public Function EnviarStatusPainel()

        Dim ip As String
        Dim TamanhoBytes As Long
        Dim EspacoLivreBytes As Long
        Dim EspacoUsadoBytes As Long
        Dim PercentualUsado As Integer
        Dim TamanhoConvertido As Double
        Dim EspacoConvertido As Double
        Dim EspacoLIvreConvertido As Double
        Dim NomeProcessador As String
        Dim totalMemoria As String

        ' Obtém Ip Externo
        Dim client As New WebClient()
        Try
            ip = client.DownloadString("https://api.ipify.org")
        Catch ex As Exception
            MessageBox.Show("Não foi possível obter o IP externo: " & ex.Message)
        End Try

        ' Obtém a unidade do sistema (geralmente C:)
        Dim drive As DriveInfo = New DriveInfo("C")

        If drive.IsReady Then

            TamanhoBytes = drive.TotalSize
            EspacoLivreBytes = drive.TotalFreeSpace
            EspacoUsadoBytes = TamanhoBytes - EspacoLivreBytes
            PercentualUsado = CInt((EspacoUsadoBytes / TamanhoBytes) * 100)
            TamanhoConvertido = ConvertBytesToGigabytes(TamanhoBytes)
            EspacoConvertido = ConvertBytesToGigabytes(EspacoUsadoBytes)
            EspacoLIvreConvertido = ConvertBytesToGigabytes(EspacoLivreBytes)

        Else
            MessageBox.Show("A unidade não está pronta.")
        End If

        ' Obtém nome Processador
        NomeProcessador = GetProcessorName()

        'Dim memoryInfo As String = GetTotalPhysicalMemory()
        totalMemoria = My.Computer.Info.TotalPhysicalMemory
        totalMemoria = FormatBytes(totalMemoria)

    End Function

    Private Sub ContextMenuStrip1_Opening(sender As Object, e As CancelEventArgs) Handles ContextMenuStrip1.Opening

    End Sub

    Private Sub Requisicao_Lote_Produtos_Activated(sender As Object, e As EventArgs) Handles Me.Activated

        Label_Consultados.Text = "Produtos Consultados: " & NumeroProdutoConsultados
        Label_Ultima_consulta.Text = "Última consulta Realizada ao Portal: " & Config_Data_Ultima_Consulta & " - " & strhoraatualizacao

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.Visible = False
        Timer1.Stop()
    End Sub

    Private Sub Panel_cabecalho_Paint(sender As Object, e As PaintEventArgs) Handles Panel_cabecalho.Paint

    End Sub
End Class